from database import add_user, get_user
from security import hash_password, check_password

def register(username, password):
    if len(password) < 6:
        return "Şifre en az 6 karakter olmalıdır."
    
    hashed = hash_password(password)
    if add_user(username, hashed):
        return "Kayıt başarılı!"
    else:
        return "Bu kullanıcı adı zaten alınmış."

def login(username, password):
    user_data = get_user(username)
    if user_data and check_password(user_data[0], password):
        return True
    return False
