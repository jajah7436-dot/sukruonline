from flask import Flask, render_template, request, redirect, flash
from auth import login, register

app = Flask(__name__)
app.secret_key = 'gizli_anahtar'

@app.route('/')
def home():
    return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    if request.method == 'POST':
        user = request.form['username']
        pwd = request.form['password']
        if login(user, pwd):
            return f"<h1>Hoş geldin {user}!</h1><p>Bu senin gizli panelin.</p>"
        else:
            return "Hatalı giriş! <a href='/login'>Tekrar dene</a>"
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register_page():
    if request.method == 'POST':
        user = request.form['username']
        pwd = request.form['password']
        mesaj = register(user, pwd)
        return f"<h1>{mesaj}</h1><a href='/login'>Giriş sayfasına git</a>"
    return render_template('register.html')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
